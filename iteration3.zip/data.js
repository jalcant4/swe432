// Data for gallery items
const data = [
    {
        img: 'beerbongs&bentleys.jpg',
        alt: 'Beerbongs & Bentleys Coverart',
        content: 'BeerBongs & Bentleys was released by Post Malone on 2018',
        timeslots: [],
    },
    {
        img: 'chase_atlantic.jpg',
        alt: 'Chase Atlantic Coverart',
        content: 'The eponymous album, Chase Atlantic, was released in 2017',
        timeslots: [],
    },
    {
        img: 'ICYMI.jpg',
        alt: 'ICYMI Coverart',
        content: 'In Case You Missed It, ICYMI, by EDEN was released in 2022',
        timeslots: [],
    },
    {
        img: 'hypochondriac.jpg',
        alt: 'hypochondriac Coverart',
        content: 'hypochondriac by brakence was released in 2022',
        timeslots: [],
    },
    {
        img: 'overthinker.jpg',
        alt: 'Allan Watts',
        content: 'Overthinker by INZO was released in 2018',
        timeslots: [],
    },
];